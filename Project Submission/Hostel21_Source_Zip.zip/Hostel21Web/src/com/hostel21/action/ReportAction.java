package com.hostel21.action;

import java.util.Map;

import com.hostel21.beans.Report;
import com.hostel21.dao.ReportDAO;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class ReportAction extends ActionSupport {
	private String fromDate;
    private String toDate;
    private String hostelName;
    Map request = (Map) ActionContext.getContext().get("request");
    public String execute() {
    	if (this.fromDate!=null && this.toDate!=null && this.hostelName!=null) {
    		Report report=ReportDAO.getData(hostelName, fromDate, toDate);
    		request.put("report", report);
    		return "success";
        } else {
            addActionError(getText("error.login"));
            return "error";
        }
    }

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getHostelName() {
		return hostelName;
	}

	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}
 

}
