package com.hostel21.action;

import java.util.List;
import java.util.Map;

import com.hostel21.beans.Availability;
import com.hostel21.beans.User;
import com.hostel21.dao.AvailabilityDAO;
import com.hostel21.dao.UserDAO;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String userId;
    private String password;
    Map<String, Object> session = ActionContext.getContext().getSession();
    Map request = (Map) ActionContext.getContext().get("request");
    public String execute() {
        if (this.userId!=null && this.password != null) {
        	User user=UserDAO.getById(userId);
        	if(user!=null && user.isUserValid(password)) {
            	session.put("user",user);
            	List<Availability> availability=AvailabilityDAO.getAll();
            	request.put("availability", availability);
                return "success";
        	}
        	else {
        		addActionError(getText("error.login"));  
        		return "error";
        	}
        } else {
            addActionError(getText("error.login"));
            return "error";
        }
    }
 
 
    public String getPassword() {
        return password;
    }
 
    public void setPassword(String password) {
        this.password = password;
    }


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}
}
