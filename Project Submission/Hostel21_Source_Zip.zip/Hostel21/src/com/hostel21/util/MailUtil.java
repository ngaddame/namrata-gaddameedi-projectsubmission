package com.hostel21.util;


public class MailUtil {
	public static void send(String toEmail,String subject,String body) {
		System.out.println("************** EMAIL ***************");
		System.out.println("EMAIL ID: "+toEmail);
		System.out.println("SUBJECT: "+subject);
		System.out.println("BODY: "+body);
		System.out.println("************************************");
				
	}
}
