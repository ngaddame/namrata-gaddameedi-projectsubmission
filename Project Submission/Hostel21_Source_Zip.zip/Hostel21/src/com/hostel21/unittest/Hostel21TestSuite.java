
package com.hostel21.unittest;

import com.hostel21.dao.DeleteDAO;

import junit.framework.TestSuite;
import junit.textui.TestRunner;

public class Hostel21TestSuite {
	public static TestSuite suite() {
    	TestSuite suite= new TestSuite();
        suite.addTest(
            new Hostel21UnitTest("Hostel21UnitTest.testHostelApplication") {
                protected void runTest() { testAll(); }
            }
        );
        
        return suite;
    }    
    
    public static void main(String arg[])   
    {   
    	cleanup();
        TestRunner.run(suite());   
    	cleanup();
    }

	private static void cleanup() {
		try {
    		DeleteDAO.deleteAll("AVAILABILITY");
    		DeleteDAO.deleteAll("HOSTEL");
    		DeleteDAO.deleteAll("CUSTOMER");
    		DeleteDAO.deleteAll("BOOKING");
    	}
    	catch(Exception e) {
    		e.printStackTrace();
    	}
	} 
}