package com.hostel21.unittest;


import java.util.List;

import org.junit.Assert;

import junit.framework.TestCase;

import com.hostel21.beans.Booking;
import com.hostel21.beans.Customer;
import com.hostel21.beans.Hostel;
import com.hostel21.beans.Report;
import com.hostel21.beans.Search;
import com.hostel21.beans.SearchResult;
import com.hostel21.beans.User;
import com.hostel21.dao.CustomerDAO;
import com.hostel21.dao.DeleteDAO;
import com.hostel21.dao.HostelDAO;
import com.hostel21.dao.ReportDAO;
import com.hostel21.dao.SearchDAO;
import com.hostel21.dao.UserDAO;
import com.hostel21.facade.BookingFacade;
import com.hostel21.load.LoadDataFromXML;
/**
 * THe main idea for testing Hostel21 application code is to load hostel data and its availability
 * in a blank database and then test it to make sure the data is getting stored correctly and retrieving 
 * the available correctly.
 */
public class Hostel21UnitTest extends TestCase {
    String name=null;
    Customer cust=null;
	String hostelName="Hostel 21 - Romantic";
	String address="424 Clay St";
	String city="San Francisco";
	String state="California";
	String postal_code="94111";
	String country="USA";
	String phone="+1-555-555-5555";
	String email="romantic@hostel21.com";
	String facebook="hostel21-romantic";
	String web="romantic.hostel21.com";
	String check_in_time="14:00";
	String check_out_time="11:00";
	String smoking="N";
	String alcohol="N";
	Integer cancellation_deadline=48;
	Double cancellation_penalty=75.0;
	
	String startDate="2014-07-01";
	String endDate="2014-07-02";
	
	Booking booking=null;
	
	User user=null;
    public Hostel21UnitTest(String name) {
    	this.name=name;
    }
    
    protected void loadData() {
    	LoadDataFromXML.load("hostel-inventory-1-20131117.xml");
    }
    protected void setUp() {
    	user=new User("stiger", "Tiger", "admin", "Scott", "Tiger");
    	loadData();
    	cust=new Customer(null, "namrata2@gmail.com", "Namarta", "Gaddameedi", "3149999999", "1234567890123456", "2017-01-01", "999");
    }
    
    
    public void testAll() {
    	//1. test hostel data loaded from xml file
    	testHostelData();
    	
    	//2. test customer add
    	testCustomerData();
    	
    	//3. test search
    	testSearch();
    	
    	//4. test booking
    	testBooking();

    	//5. test report revenue, occupancy
    	testReport();

    	//6. test cancel booking
    	testCancelBooking();
    	
    	//7. test modify customer
    	modifyCustomer();
    	
    	//8. add user
    	testUser();
    }
    
    public void testUser() {
    	UserDAO.add(user);
    	User newUser=UserDAO.getById(user.getUserId());
    	Assert.assertEquals(user.getUserId(), newUser.getUserId());
    	Assert.assertEquals(user.getPassword(), newUser.getPassword());
    }
    
    
    public void testReport() {
    	Report report=ReportDAO.getData(hostelName, startDate, endDate);
    	Assert.assertEquals(report.getRevenue(), new Double(42.0));
    	Assert.assertEquals(report.getBookings(), new Integer(1));
    	Assert.assertEquals(report.getOcupancy_rate(), new Double(100));
    	
    }
    public void testSearch() {
    	/*
			<availability>
				<date>20140701</date>
				<room>1</room>
				<bed>1</bed>
				<price>10</price>
			</availability>
			<availability>
				<date>20140701</date>
				<room>1</room>
				<bed>2</bed>
				<price>12</price>
			</availability>
			<availability>
				<date>20140701</date>
				<room>2</room>
				<bed>3</bed>
				<price>20</price>
			</availability> 
			no of bed=3, min price=10, max price=20   	 
    	 */
    	SearchResult result=SearchDAO.search(startDate, endDate, hostelName);
    	Assert.assertTrue(result!=null);
    	Assert.assertEquals(result.getFromDate(), startDate);
    	Assert.assertEquals(result.getToDate(), endDate);
    	Assert.assertEquals(result.getHostelName(), hostelName);
    	List<Search> list=result.getList();
    	Search search=list.get(0);
    	Assert.assertEquals(search.getMinPrice(), new Double(10.0));
    	Assert.assertEquals(search.getMaxPrice(), new Double(20.0));
    	Assert.assertEquals(search.getNoOfBeds(), new Integer(3));
    }
    
    public void modifyCustomer() {
    	CustomerDAO.modify(cust.getCustomerId(), "Namrata New", "Gaddameedi New", cust.getEmailId(),cust.getCcNumber(), cust.getCcExpireDate(), cust.getCcSecurityCode(), cust.getCustPhone(), cust.getFacebook(), cust.getWeb());
    	Customer modified=CustomerDAO.getByCustomerId(cust.getCustomerId());
    	Assert.assertEquals(modified.getFirstName(),"Namrata New" );
    	Assert.assertEquals(modified.getLastName(),"Gaddameedi New" );
    }
    
    public void testBooking() {
    	/*
			<availability>
				<date>20140701</date>
				<room>1</room>
				<bed>1</bed>
				<price>10</price>
			</availability>
			<availability>
				<date>20140701</date>
				<room>1</room>
				<bed>2</bed>
				<price>12</price>
			</availability>
			<availability>
				<date>20140701</date>
				<room>2</room>
				<bed>3</bed>
				<price>20</price>
			</availability> 
			no of bed=3, min price=10, max price=20   	 
    	 */
    	
    	//step1: search
    	SearchResult result=SearchDAO.search(startDate, endDate, hostelName,3);
    	Assert.assertTrue(result!=null);
    	Assert.assertEquals(result.getFromDate(), startDate);
    	Assert.assertEquals(result.getToDate(), endDate);
    	Assert.assertEquals(result.getHostelName(), hostelName);
    	List<Search> list=result.getList();
    	Search search=list.get(0);
  	    Assert.assertEquals(search.getNoOfBeds(), new Integer(3));
  	    Assert.assertEquals(search.getTotalPrice(), new Double(42.0));
  	    
  	    //step2: book.
  	    booking=BookingFacade.book(startDate, endDate, hostelName, 3, search.getAvailableBedIds(), search.getTotalPrice(), cust, "unittest");
  	    Assert.assertEquals(booking.getCheckinDate(), startDate);
  	    Assert.assertEquals(booking.getCheckoutDate(), endDate);
  	    Assert.assertEquals(booking.getStatus(), "Booked");
  	    Assert.assertEquals(booking.getBookingPrice(), search.getTotalPrice());
  	    Assert.assertEquals(booking.getCancelFee(), new Double(0.0));
    }
    
    public void testCancelBooking() {
    	Booking cancelled=BookingFacade.cancel(booking.getBookingId(), "unittest");
    	Assert.assertEquals(booking.getBookingId(), cancelled.getBookingId());
    	Assert.assertEquals(cancelled.getStatus(),"Cancelled");
    	Assert.assertEquals(booking.getCancelFee(), new Double(0.0));    	
    }
    
    public void testHostelData() {
    	Hostel hostel=HostelDAO.getByHostelName("Hostel 21 - Romantic");
    	Assert.assertTrue(hostel!=null);
    	Assert.assertEquals(hostel.getName(), hostelName);
    	Assert.assertEquals(hostel.getStreet(), address);
    	Assert.assertEquals(hostel.getCity(), city);
    	Assert.assertEquals(hostel.getState(), state);
    	Assert.assertEquals(hostel.getPostalCode(), postal_code);
    	Assert.assertEquals(hostel.getCountry(), country);
    	Assert.assertEquals(hostel.getPhone(), phone);
    	Assert.assertEquals(hostel.getEmail(), email);
    	Assert.assertEquals(hostel.getFacebook(), facebook);
    	Assert.assertEquals(hostel.getWeb(), web);
    	Assert.assertEquals(hostel.getCheckinTime(), check_in_time);
    	Assert.assertEquals(hostel.getCheckoutTime(), check_out_time);
    	Assert.assertEquals(hostel.getSmoking(), smoking);
    	Assert.assertEquals(hostel.getAlcohol(), alcohol);
    	Assert.assertEquals(hostel.getCancellationDeadline(), cancellation_deadline);
    	Assert.assertEquals(hostel.getCancellPenalty(), cancellation_penalty);
    }
    
    
    public void testCustomerData() {
    	CustomerDAO.add(cust);
    	Customer newCust=CustomerDAO.getByEmailId(cust.getEmailId());
    	Assert.assertTrue(newCust!=null);
    	Assert.assertEquals(newCust.getEmailId(), cust.getEmailId());
    	Assert.assertEquals(newCust.getFirstName(), cust.getFirstName());
    	Assert.assertEquals(newCust.getLastName(), cust.getLastName());
    	Assert.assertEquals(newCust.getCustPhone(), cust.getCustPhone());
    	Assert.assertEquals(newCust.getCcNumber(), cust.getCcNumber());
    	Assert.assertEquals(newCust.getCcExpireDate(), cust.getCcExpireDate());
    	Assert.assertEquals(newCust.getCcSecurityCode(), cust.getCcSecurityCode());
    	Assert.assertEquals(newCust.getFacebook(), cust.getFacebook());
    	Assert.assertEquals(newCust.getWeb(), cust.getWeb());
    	cust=newCust;
    }
 }