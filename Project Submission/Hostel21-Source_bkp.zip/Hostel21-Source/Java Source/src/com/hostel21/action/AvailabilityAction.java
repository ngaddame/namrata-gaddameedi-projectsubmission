package com.hostel21.action;

import java.util.List;
import java.util.Map;

import com.hostel21.beans.Availability;
import com.hostel21.dao.AvailabilityDAO;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class AvailabilityAction extends ActionSupport {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String fromDate;
    private String toDate;
    private String hostelName;
    Map request = (Map) ActionContext.getContext().get("request");
    public String execute() {
    	if (this.fromDate!=null && this.toDate!=null && this.hostelName!=null) {
        	List<Availability> availability=AvailabilityDAO.getAll(hostelName,fromDate, toDate);
        	request.put("availability", availability);
        	return "success";
        } else {
        	List<Availability> availability=AvailabilityDAO.getAll();
        	request.put("availability", availability);
            addActionError(getText("schedule.default"));
            return "error";
        }
    }

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getHostelName() {
		return hostelName;
	}

	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}
 

}
