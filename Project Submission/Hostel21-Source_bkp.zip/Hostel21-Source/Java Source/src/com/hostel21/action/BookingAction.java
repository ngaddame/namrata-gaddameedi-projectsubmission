package com.hostel21.action;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.hostel21.beans.Booking;
import com.hostel21.beans.Customer;
import com.hostel21.beans.Hostel;
import com.hostel21.beans.Search;
import com.hostel21.beans.SearchResult;
import com.hostel21.beans.User;
import com.hostel21.dao.BookingDAO;
import com.hostel21.dao.CustomerDAO;
import com.hostel21.dao.SearchDAO;
import com.hostel21.facade.BookingFacade;
import com.hostel21.util.DateUtil;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class BookingAction extends ActionSupport {
	private String subAction;
    /**
	 * 
	 */
    Map<String, Object> session = ActionContext.getContext().getSession();
    Map request = (Map) ActionContext.getContext().get("request");
    
    //search parameters.
    private String hostelName;
	private String checkinDate;
    private String checkoutDate;
    private String noOfBeds;
    private String bookingPrice;
    private String availableBedIds;
    
    
    //customer information required for booking.
    private String customerId;
    private String firstName;
    private String lastName;
    private String ccNumber;
    private String ccExpireDate;
    private String ccSecurityCode;
    private String phone;
    private String email;
    private String facebook;
    private String twitter;
    private String bookingId; 
    
    public String confirm() {
        if (email!=null) {
    		Customer customer=CustomerDAO.getByEmailId(email);
    		if(customer!=null) {
	    	    customerId=customer.getCustomerId().toString();
	    	    firstName=customer.getFirstName();
	    	    lastName=customer.getLastName();
	    	    ccNumber=customer.getCcNumber();
	    	    ccExpireDate=customer.getCcExpireDate();
	    	    ccSecurityCode=customer.getCcSecurityCode();
	    	    phone=customer.getCustPhone();
	    	    facebook=customer.getFacebook();
	    	    twitter=customer.getTwitter();
    		}
    		else {
    			addActionError(getText("error.customer"));
    		}
        } else {
            addActionError(getText("error.customer"));
        }
        return "success";
    }
    
    public String save() {
        if (firstName!=null && lastName!=null && phone!=null && email!=null) {
        	User user=(User) session.get("user");
        	Customer customer=null;
        	if(customerId==null || "".equals(customerId)) {
        		customer=new Customer(null, email, firstName, lastName, phone, ccNumber, ccExpireDate, ccSecurityCode);
        		customer.setFacebook(facebook);customer.setTwitter(twitter);
        		customer=CustomerDAO.add(customer);
        	}
        	else {
        		CustomerDAO.modify(Integer.parseInt(customerId),  firstName, lastName, email, ccNumber, ccExpireDate, ccSecurityCode,phone,facebook,twitter);
        		customer=CustomerDAO.getByCustomerId(Integer.parseInt(customerId));
        	}
        	SearchResult searchResult=(SearchResult) session.get("searchResult");
        	Search result=searchResult.getList().get(0);
        	session.remove("searchResult");
        	Booking booking=BookingFacade.book(searchResult.getFromDate(), searchResult.getToDate(), searchResult.getHostelName(), searchResult.getNoOfBedsRequested(), result.getAvailableBedIds(), result.getTotalPrice(), customer, user==null?"system":user.getUserId());
        	request.put("booking", booking);
            return "success";
        } else {
            addActionError(getText("error.customer"));
            return "error";
        }
    }

    
    public String search() {
        if (this.checkinDate!=null && this.checkoutDate!=null && this.hostelName!=null) {
        	SearchResult searchResult=null;
        	if(noOfBeds==null || "".equals(noOfBeds)) {
        		searchResult=SearchDAO.search(checkinDate, checkoutDate, hostelName);
        	}
        	else {
        		searchResult=SearchDAO.search(checkinDate, checkoutDate, hostelName, Integer.parseInt(noOfBeds));
        	}
        	if(searchResult.getList().size()==0) {
        		addActionError(getText("no_availability"));
        	}
        	else {
            	session.put("searchResult", searchResult);
        	}
       		return "success";
        } else {
            addActionError(getText("no_availability"));
            return "error";
        }
    }
    
    public String searchBooking() {
    	if(this.bookingId!=null && "".equals(bookingId)==false) {
    		Booking booking=BookingDAO.getByBookingId(Integer.parseInt(bookingId));
    		request.put("booking", booking);
    		return "details";
    	}
    	else if(this.email!=null && "".equals(email)==false) {
    		List<Booking> bookings=BookingDAO.getByCustoEmail(this.email);
    		request.put("bookingList", bookings);
    		return "bookingList";
    	}
    	else {
            addActionError(getText("no_booking_exists"));
            return "error";
    	}
    }    
    
    public String cancel() {
        if (this.bookingId!=null) {
        	Booking booking=BookingDAO.getByBookingId(Integer.parseInt(bookingId));
        	Hostel hostel=booking.getHostel();
        	Date checkinDateNew=DateUtil.convertToDate(booking.getCheckinDate(), "yyyy-MM-dd");
        	int days=DateUtil.daysBetween(checkinDateNew, new Date());
        	if(days<=hostel.getCancellationDeadline()/24) {
        		User user=(User) session.get("user");
        		booking=BookingFacade.cancel(Integer.parseInt(bookingId), user.getUserId());
	        	if(booking!=null) {
	        		request.put("booking", booking);
	        	}
        	}
        	else {
        		addActionError(getText("cancel_not_allowed"));
        		
        	}
        	return "success";
        } 
        addActionError(getText("no_availability"));
        return "error";
    }      

	public String getHostelName() {
		return hostelName;
	}

	public void setHostelName(String hostelName) {
		this.hostelName = hostelName;
	}

	public String getCheckinDate() {
		return checkinDate;
	}
	public void setCheckinDate(String checkinDate) {
		this.checkinDate = checkinDate;
	}
	public String getCheckoutDate() {
		return checkoutDate;
	}
	public void setCheckoutDate(String checkoutDate) {
		this.checkoutDate = checkoutDate;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	public String getFacebook() {
		return facebook;
	}
	public void setFacebook(String facebook) {
		this.facebook = facebook;
	}
	public String getTwitter() {
		return twitter;
	}
	public String getCcNumber() {
		return ccNumber;
	}

	public void setCcNumber(String ccNumber) {
		this.ccNumber = ccNumber;
	}

	public String getCcExpireDate() {
		return ccExpireDate;
	}

	public void setCcExpireDate(String ccExpireDate) {
		this.ccExpireDate = ccExpireDate;
	}

	public String getCcSecurityCode() {
		return ccSecurityCode;
	}

	public void setCcSecurityCode(String ccSecurityCode) {
		this.ccSecurityCode = ccSecurityCode;
	}

	public void setTwitter(String twitter) {
		this.twitter = twitter;
	}

	public String getNoOfBeds() {
		return noOfBeds;
	}

	public void setNoOfBeds(String noOfBeds) {
		this.noOfBeds = noOfBeds;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getBookingPrice() {
		return bookingPrice;
	}

	public void setBookingPrice(String bookingPrice) {
		this.bookingPrice = bookingPrice;
	}

	public String getAvailableBedIds() {
		return availableBedIds;
	}

	public void setAvailableBedIds(String availableBedIds) {
		this.availableBedIds = availableBedIds;
	}
 
}
